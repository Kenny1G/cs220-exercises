//Kenny Oseleononmen
//koseleo1
#include <stdio.h>

int main()
{
	printf("The first prize goes to Harry.\n");
	return 0;
}
