// Kenny Oseleononmen
// koseleo1
#include <stdio.h>

int main()
{
	printf ("The third prize goes to Ron.\n");
	return 0;
}
