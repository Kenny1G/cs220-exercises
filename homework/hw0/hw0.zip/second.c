// Kenny Oseleononmen
// koseleo1
#include <stdio.h>
int main()
{
	printf("The second prize goes to Hermione.\n");
	return 0;
}
